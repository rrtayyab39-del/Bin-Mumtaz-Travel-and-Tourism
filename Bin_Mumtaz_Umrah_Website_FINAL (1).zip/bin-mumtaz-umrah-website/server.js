const express = require("express");
const session = require("express-session");
const nodemailer = require("nodemailer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data.json");

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "replace-me",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:false, maxAge:1000*60*60*8}
}));
app.use(express.static(path.join(__dirname, "public")));

function load(){ return JSON.parse(fs.readFileSync(DATA,"utf8")); }
function save(d){ fs.writeFileSync(DATA, JSON.stringify(d,null,2)); }

app.post("/api/customer/register",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase();
  const password=String(req.body.password||"");
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:"Enter a valid email"});
  if(password.length<8) return res.status(400).json({error:"Website password must be at least 8 characters"});
  const d=load();
  d.customers=d.customers||{};
  if(d.customers[email]) return res.status(409).json({error:"Account already exists. Please login."});
  d.customers[email]={passwordHash:bcrypt.hashSync(password,12),createdAt:new Date().toISOString()};
  save(d);
  req.session.customer={email};
  res.json({ok:true});
});

app.post("/api/customer/login",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase();
  const password=String(req.body.password||"");
  const d=load();
  const c=(d.customers||{})[email];
  if(!c || !bcrypt.compareSync(password,c.passwordHash))
    return res.status(401).json({error:"Invalid email or website password"});
  req.session.customer={email};
  res.json({ok:true});
});

app.post("/api/admin/login",(req,res)=>{
  const password=String(req.body.password||"");
  const d=load();
  let ok=bcrypt.compareSync(password,d.admin.passwordHash);
  if(d.admin.passwordHash==="PLAIN_DEMO:Bin Mumtaz 2026" && password==="Bin Mumtaz 2026"){
    ok=true;
    d.admin.passwordHash=bcrypt.hashSync(password,12);
    save(d);
  }
  if(!ok) return res.status(401).json({error:"Invalid admin password"});
  req.session.admin={ok:true};
  res.json({ok:true});
});

app.post("/api/admin/change-password",requireAdmin,(req,res)=>{
  const p=String(req.body.password||"");
  if(p.length<8) return res.status(400).json({error:"Password must be at least 8 characters"});
  const d=load();
  d.admin.passwordHash=bcrypt.hashSync(p,12);
  save(d);
  res.json({ok:true});
});

app.get("/api/packages",requireCustomer,(req,res)=>res.json(load().packages));

app.post("/api/admin/package",requireAdmin,(req,res)=>{
  const d=load(), p=req.body;
  if(!p.id) p.id="BM-"+String(Date.now()).slice(-6);
  p.days=Number(p.days||0); p.seats=Number(p.seats||0);
  p.prices={
    sharing:Number(p.prices?.sharing||0),
    quad:Number(p.prices?.quad||0),
    triple:Number(p.prices?.triple||0),
    double:Number(p.prices?.double||0)
  };
  const i=d.packages.findIndex(x=>x.id===p.id);
  if(i>=0) d.packages[i]=p; else d.packages.push(p);
  save(d); res.json(p);
});

app.delete("/api/admin/package/:id",requireAdmin,(req,res)=>{
  const d=load(); d.packages=d.packages.filter(p=>p.id!==req.params.id); save(d);
  res.json({ok:true});
});

app.post("/api/bookings",requireCustomer,(req,res)=>{
  const d=load();
  const b={...req.body,id:"BK-"+Date.now(),customerEmail:req.session.customer.email,createdAt:new Date().toISOString()};
  d.bookings.push(b); save(d); res.json({ok:true,booking:b});
});

app.get("/api/admin/bookings",requireAdmin,(req,res)=>res.json(load().bookings));
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Bin Mumtaz website running on http://localhost:${PORT}`));
