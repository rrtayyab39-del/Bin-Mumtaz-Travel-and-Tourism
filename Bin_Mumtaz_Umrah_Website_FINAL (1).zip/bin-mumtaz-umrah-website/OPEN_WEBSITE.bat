@echo off
title Bin Mumtaz Travel & Tourism
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js is not installed. Install Node.js LTS first.
 pause
 exit /b
)
if not exist node_modules call npm install
start "" http://localhost:3000
npm start
