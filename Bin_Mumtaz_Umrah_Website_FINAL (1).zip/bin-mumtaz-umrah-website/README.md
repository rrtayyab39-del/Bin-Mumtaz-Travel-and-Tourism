# Bin Mumtaz Travel & Tourism — Umrah Website

## Login system
- Admin login requires **only the Admin password**.
- Customers register/login with **their email + a password created specifically for the Bin Mumtaz website**.
- No OTP is used.
- The website must NEVER ask customers for their Gmail/Google password.

## Features
- Uploaded Bin Mumtaz logo
- Makkah/Madinah themed landing page
- Admin-only package create/edit/delete
- Package number/name, days, date, seats
- Flight name, Sector 1, Sector 2
- Makkah/Madinah hotels and distances
- Transport and residence
- Sharing / Quad / Triple / Double prices
- Customer booking
- Admin bookings list
- Admin password change

## Run locally
1. Install Node.js LTS.
2. Open terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Default admin password for this demo:
`ChangeMe123!`

Change it immediately from the Admin Dashboard.

## Security
Customer email-provider passwords (Gmail/Google passwords) are intentionally not collected or stored. Use a separate website password. For production, add HTTPS, rate limiting, a real database, secure cookies, backups and proper password-reset/recovery.
